package com.example.demo.enums;

public enum Status {
    UNAPPROVED,
    APPROVED,
    SOLD
}

