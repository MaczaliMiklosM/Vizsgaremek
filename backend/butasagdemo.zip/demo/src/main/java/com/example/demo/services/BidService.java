package com.example.demo.services;

import com.example.demo.dto.bid.BidDTO;  // A BidDTO importálása
import com.example.demo.enums.BidStatus;
import com.example.demo.enums.Status;
import com.example.demo.model.Bid;
import com.example.demo.model.Product;
import com.example.demo.model.User;
import com.example.demo.repository.BidRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BidService {

    private final BidRepository bidRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public Bid placeBid(Integer productId, Integer userId, Double amount) throws Exception {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new Exception("Product not found"));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new Exception("User not found"));

        // 🔒 Ne engedjünk új licitet, ha már van aktív
        if (bidRepository.existsByProductIdAndBidderIdAndStatus(productId, userId, BidStatus.PENDING)) {
            throw new Exception("You already have an active bid for this product.");
        }

        if (product.getStatus().equals("SOLD")) {
            throw new Exception("Product already sold");
        }

        if (amount >= product.getPrice()) {
            throw new Exception("Offer is equal or greater than price. You should buy it directly.");
        }

        Bid bid = new Bid();
        bid.setProduct(product);
        bid.setBidder(user);
        bid.setAmount(amount);
        bid.setTime(LocalDateTime.now());
        bid.setStatus(BidStatus.PENDING);

        return bidRepository.save(bid);
    }


    public List<BidDTO> findByProductId(Integer productId) {
        return bidRepository.findByProductId(productId).stream()
                .map(bid -> new BidDTO(bid.getId(), bid.getAmount(), bid.getTime(), bid.getStatus().name(), bid.getProduct().getId(), bid.getBidder().getId()))
                .collect(Collectors.toList());
    }

    public List<BidDTO> findReceivedBids(Integer uploaderId) {
        return bidRepository.findByProductUserId(uploaderId).stream()
                .map(bid -> new BidDTO(bid.getId(), bid.getAmount(), bid.getTime(), bid.getStatus().name(), bid.getProduct().getId(), bid.getBidder().getId()))
                .collect(Collectors.toList());
    }

    public void acceptBid(Integer bidId) {
        Bid bid = bidRepository.findById(bidId).orElseThrow();
        bid.setStatus(BidStatus.ACCEPTED);
        bid.getProduct().setStatus(Status.valueOf("SOLD"));
        bidRepository.save(bid);
    }

    public void rejectBid(Integer bidId) {
        Bid bid = bidRepository.findById(bidId).orElseThrow();
        bid.setStatus(BidStatus.REJECTED);
        bidRepository.save(bid);
    }

    public List<Bid> findByUserId(Integer userId) {
        return bidRepository.findByProductUserId(userId); // vagy findByUserId
    }

}
