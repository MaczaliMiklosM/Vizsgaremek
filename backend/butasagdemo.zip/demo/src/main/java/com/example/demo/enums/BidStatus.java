package com.example.demo.enums;

public enum BidStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}
