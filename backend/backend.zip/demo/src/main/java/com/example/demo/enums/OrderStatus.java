package com.example.demo.enums;


public enum OrderStatus {
    PROCESSING,
    CART,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
