package com.example.demo.enums;

public enum TargetGender {
    MAN,
    WOMAN,
}

