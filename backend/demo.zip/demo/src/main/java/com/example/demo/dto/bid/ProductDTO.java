package com.example.demo.dto.bid;
import lombok.Data;

@Data
public class ProductDTO {

    private Integer id;
    private String name;
    private Double price;
    private String description;
    private String imageUrl;

    // Konstruktor
    public ProductDTO(Integer id, String name, Double price, String description, String imageUrl) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.description = description;
        this.imageUrl = imageUrl;
    }
}
