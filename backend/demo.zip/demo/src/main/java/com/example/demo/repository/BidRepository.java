package com.example.demo.repository;

import com.example.demo.model.Bid;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BidRepository extends JpaRepository<Bid, Integer> {
    List<Bid> findByProductId(Integer productId);
    List<Bid> findByProductUserId(Integer uploaderId); // <-- EZ a helyes
}
