package com.example.demo.controller;

import com.example.demo.dto.bid.BidDTO;  // A BidDTO importálása
import com.example.demo.model.Bid;
import com.example.demo.services.BidService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import com.example.demo.services.JWTUtils;
import com.example.demo.services.UserDetailService;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/bids")
@RequiredArgsConstructor
public class BidController {
    @Autowired
    private JWTUtils jwtUtils;
    private final BidService bidService;
    @Autowired
    private UserDetailService ourUserDetailsService;
    @PostMapping("/place")
    public ResponseEntity<?> placeBid(@RequestParam Integer productId,
                                      @RequestParam Integer userId,
                                      @RequestParam Double amount,
                                      @RequestHeader("Authorization") String authHeader) {
        // Ellenőrizzük, hogy a kérés tartalmazza a JWT token-t
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(403).body("Forbidden: Missing or invalid token.");
        }

        // Token levágása és validálása
        String token = authHeader.substring(7);  // "Bearer " eltávolítása
        try {
            String userEmail = jwtUtils.extractUsername(token);
            UserDetails userDetails = ourUserDetailsService.loadUserByUsername(userEmail);

            if (jwtUtils.isTokenValid(token, userDetails)) {
                // A Bid entitás és DTO-k létrehozása
                Bid bid = bidService.placeBid(productId, userId, amount);
                BidDTO bidDTO = new BidDTO(bid.getId(), bid.getAmount(), bid.getTime(), bid.getStatus().name(), bid.getProduct().getId(), bid.getBidder().getId());
                return ResponseEntity.ok(bidDTO);
            } else {
                return ResponseEntity.status(403).body("Forbidden: Invalid token.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(403).body("Forbidden: Invalid token.");
        }
    }


    @GetMapping("/product/{productId}")
    public ResponseEntity<List<BidDTO>> getBidsForProduct(@PathVariable Integer productId) {
        List<BidDTO> bidDTOs = bidService.findByProductId(productId).stream()
                .map(bid -> new BidDTO(bid.getId(), bid.getAmount(), bid.getTime(), bid.getStatus(), bid.getProductId(), bid.getUserId()))
                .collect(Collectors.toList());
        return ResponseEntity.ok(bidDTOs);
    }

    @PostMapping("/accept/{bidId}")
    public ResponseEntity<?> acceptBid(@PathVariable Integer bidId) {
        bidService.acceptBid(bidId);
        return ResponseEntity.ok("Bid accepted and product marked as SOLD.");
    }

    @PostMapping("/reject/{bidId}")
    public ResponseEntity<?> rejectBid(@PathVariable Integer bidId) {
        bidService.rejectBid(bidId);
        return ResponseEntity.ok("Bid rejected.");
    }
}
