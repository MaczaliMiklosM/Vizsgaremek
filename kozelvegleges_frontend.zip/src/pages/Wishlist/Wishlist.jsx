import React, { useState } from 'react';
import Header from '../../components/Header/Header';
import Navbar from '../../components/Navbar/Navbar';
import Footer from '../../components/Footer/Footer';
import DeleteIcon from '@mui/icons-material/Delete'; 
import './Wishlist.css';

const Favorites = () => {
  const [favorites, setFavorites] = useState([
    { 
      id: 1, 
      name: "", 
      price: "$", 
      image: "/Images/" 
    },
  ]);

  const removeFromFavorites = (id) => {
    setFavorites(favorites.filter(product => product.id !== id));
  };

  return (
    <div className="container">
      <Header />
      <Navbar />
      <div className="favorites-container">
        <h1>Wishlist</h1>

        <div className="favorites-list">
          {favorites.length > 0 ? (
            favorites.map(product => (
              <div key={product.id} className="favorite-item">
                <img src={product.image} alt={product.name} className="favorite-image" />
                <div className="favorite-details">
                  <h2>{product.name}</h2>
                  <p className="favorite-price">{product.price}</p>
                </div>
                <button 
                  className="remove-favorite-btn"
                  onClick={() => removeFromFavorites(product.id)}
                >
                  <DeleteIcon fontSize="small" style={{ marginRight: '5px' }} />
                  Remove
                </button>
              </div>
            ))
          ) : (
            <p className="no-favorites">You don't have any favorite yet</p>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Favorites;
