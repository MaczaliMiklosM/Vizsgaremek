import React, { useState, useEffect } from "react";
import { useParams, useLocation, Link } from "react-router-dom";
import Header from '../../components/Header/Header';
import Navbar from '../../components/Navbar/Navbar';
import Footer from '../../components/Footer/Footer';
import FilterSidebar from '../../components/Sidebar/FilteredSideBar';
import './ProductsPage.css';

const allProducts = [ 
  {
    id: 952,
    name: "OnTheGo Tote Spring in the City Monogram Giant Canvas GM",
    gender: "woman",
    category: "bag",
    brand: "LouisVuitton",
    color: "white",
    size: "s/m/l",
    price: 5020,
    image: "/Images/product_images/taska1.jpeg"
  },
  {
    id: 953,
    name: "Clutch Box Bag Monogram Mirror",
    gender: "woman",
    category: "bag",
    brand: "LouisVuitton",
    color: "white",
    size: "m/l",
    price: 5715,
    image: "/Images/product_images/taska2_1.jpeg"
  },
  {
    id: 954,
    name: "Wallet Trunk Damoflage Canvas",
    gender: "woman",
    category: "bag",
    brand: "LouisVuitton",
    color: "green",
    size: "m/l",
    price: 5900,
    image: "/Images/product_images/taska3_1.jpeg"
  },
  {
    id: 955,
    name: "Coussin Bag Denim Printed Monogram Embossed Lambskin MM",
    gender: "woman",
    category: "bag",
    brand: "LouisVuitton",
    color: "black",
    size: "l",
    price: 5275,
    image: "/Images/product_images/taska4_1.jpeg"
  },
  {
    id: 956,
    name: "Jypsiere Bag Clemence 31",
    gender: "woman",
    category: "bag",
    brand: "Hermes",
    color: "brown",
    size: "s/m/l",
    price: 5700,
    image: "/Images/product_images/taska5_1.jpeg"
  },
  {
    id: 957,
    name: "Shoulder Kelly Bag Clemence 42",
    gender: "woman",
    category: "bag",
    brand: "Hermes",
    color: "blue",
    size: "l",
    price: 6380,
    image: "/Images/product_images/taska6_1.jpeg"
  },
  {
    id: 958,
    name: "Geta Bag Chevre Mysore",
    gender: "woman",
    category: "bag",
    brand: "Hermes",
    color: "pink",
    size: "s/m/l",
    price: 6145,
    image: "/Images/product_images/taska7_1.jpeg"
  },
  {
    id: 959,
    name: "Quilted Metal Top Handle Flap Banameg Quilted Lambskin Small",
    gender: "woman",
    category: "bag",
    brand: "Chanel",
    color: "white",
    size: "s/l",
    price: 5880,
    image: "/Images/product_images/taska8_1.jpeg"
  },
  {
    id: 960,
    name: "Classic Single Flap Bag Quilted Caviar Jumbo",
    gender: "woman",
    category: "bag",
    brand: "Chanel",
    color: "black",
    size: "l",
    price: 5385,
    image: "/Images/product_images/taska9_1.jpeg"
  },
  {
    id: 961,
    name: "Classic Double Flap Bag Quilted Patent Medium",
    gender: "woman",
    category: "bag",
    brand: "Chanel",
    color: "red",
    size: "m/l",
    price: 5080,
    image: "/Images/product_images/taska10_1.jpeg"
  },
  {
    id: 962,
    name: "Seamaster Professional Diver 300M Co-Axial Master Chronometer",
    gender: "man",
    category: "watch",
    brand: "Omega",
    color: "black",
    size: "42",
    price: 4740,
    image: "/Images/product_images/orak1_1.jpeg"
  },
  {
    id: 963,
    name: "Seamaster Professional Planet Ocean 600M Co-Axial Chronometer",
    gender: "man",
    category: "watch",
    brand: "Omega",
    color: "black",
    size: "39",
    price: 5195,
    image: "/Images/product_images/orak2_1.jpeg"
  },
  {
    id: 964,
    name: "Seamaster Professional Diver 300M Co-Axial Chronometer",
    gender: "man",
    category: "watch",
    brand: "Omega",
    color: "blue",
    size: "39/42/42",
    price: 5600,
    image: "/Images/product_images/orak3_1.jpeg"
  },
  {
    id: 965,
    name: "Must de Cartier Tank Quartz Watch",
    gender: "unisex",
    category: "watch",
    brand: "Cartier",
    color: "white",
    size: "22",
    price: 6050,
    image: "/Images/product_images/orak4_1.jpeg"
  },
  {
    id: 966,
    name: "Santos Dumont Quartz Watch Rose Gold and Alligator",
    gender: "man",
    category: "watch",
    brand: "Cartier",
    color: "white",
    size: "31",
    price: 13650,
    image: "/Images/product_images/orak5_1.jpeg"
  },
  {
    id: 967,
    name: "Ballon Blanc de Cartier Quartz Watch",
    gender: "man",
    category: "watch",
    brand: "Cartier",
    color: "white",
    size: "30",
    price: 7020,
    image: "/Images/product_images/orak6_1.jpeg"
  },
  {
    id: 968,
    name: "Tank Francaise Quartz Watch",
    gender: "unisex",
    category: "watch",
    brand: "Cartier",
    color: "white",
    size: "20",
    price: 7010,
    image: "/Images/product_images/orak7_1.jpeg"
  },
  {
    id: 969,
    name: "Oyster Perpetual Datejust Stainless Steel and Yellow Gold",
    gender: "unisex",
    category: "watch",
    brand: "Rolex",
    color: "black",
    size: "26/29",
    price: 6785,
    image: "/Images/product_images/orak8_1.jpeg"
  },
  {
    id: 970,
    name: "Oyster Perpetual Automatic Watch Stainless Steel",
    gender: "man",
    category: "watch",
    brand: "Rolex",
    color: "black",
    size: "36",
    price: 8310,
    image: "/Images/product_images/orak9_1.jpeg"
  },
  {
    id: 971,
    name: "Oyster Perpetual Datejust with Diamond Markers",
    gender: "man",
    category: "watch",
    brand: "Rolex",
    color: "black",
    size: "36/39",
    price: 8645,
    image: "/Images/product_images/orak10_1.jpeg"
  },
  {
    id: 972,
    name: "Skater Sneakers Cannage Quilt Leather",
    gender: "man",
    category: "sneaker",
    brand: "Dior",
    color: "grey",
    size: "42",
    price: 1370,
    image: "/Images/product_images/cipok1.jpeg"
  },
  {
    id: 973,
    name: "Skater Sneakers Cannage Quilt Tweed",
    gender: "man",
    category: "sneaker",
    brand: "Dior",
    color: "grey",
    size: "41/43",
    price: 1030,
    image: "/Images/product_images/cipok2_1.jpeg"
  },
  {
    id: 974,
    name: "High-Top Sneakers Maxi Oblique Canvas",
    gender: "woman",
    category: "sneaker",
    brand: "Dior",
    color: "grey",
    size: "38",
    price: 910,
    image: "/Images/product_images/cipok3_1.jpeg"
  },
  {
    id: 975,
    name: "Runner Sneakers Mesh and Nylon (Red)",
    gender: "unisex",
    category: "sneaker",
    brand: "Balenciaga",
    color: "red",
    size: "39/40",
    price: 715,
    image: "/Images/product_images/cipok4_1.jpeg"
  },
  {
    id: 976,
    name: "Runner Sneakers Mesh and Nylon (Pink 37)",
    gender: "woman",
    category: "sneaker",
    brand: "Balenciaga",
    color: "pink",
    size: "37",
    price: 645,
    image: "/Images/product_images/cipok5_1.jpeg"
  },
  {
    id: 977,
    name: "Runner Sneakers Mesh and Nylon (Pink 38)",
    gender: "woman",
    category: "sneaker",
    brand: "Balenciaga",
    color: "pink",
    size: "38",
    price: 645,
    image: "/Images/product_images/cipok6_1.jpeg"
  },
  {
    id: 978,
    name: "Trainer Sneakers Monogram Empreinte Leather and Denim",
    gender: "man",
    category: "sneaker",
    brand: "LouisVuitton",
    color: "blue",
    size: "41/43/45",
    price: 1200,
    image: "/Images/product_images/cipok7_1.jpeg"
  },
  {
    id: 979,
    name: "Wonderland Flat Ranger Boots Monogram",
    gender: "woman",
    category: "sneaker",
    brand: "LouisVuitton",
    color: "brown",
    size: "38",
    price: 2075,
    image: "/Images/product_images/cipok8_1.jpeg"
  },
  {
    id: 980,
    name: "Skate Sneakers Technical Mesh with Suede",
    gender: "man",
    category: "sneaker",
    brand: "LouisVuitton",
    color: "blue",
    size: "42/44",
    price: 1415,
    image: "/Images/product_images/cipok9_1.jpeg"
  },
  {
    id: 981,
    name: "Runner Tatic Sneakers Technical Mesh",
    gender: "man",
    category: "sneaker",
    brand: "LouisVuitton",
    color: "white",
    size: "43",
    price: 880,
    image: "/Images/product_images/cipok10_1.jpeg"
  }
];

function normalizeProducts(products) {
  return products.map(p => ({
    ...p,
    category: p.category.toLowerCase(),
    gender: p.gender.toLowerCase(),
    brand: p.brand.toLowerCase().replace(/\s/g, ''),
    color: p.color.toLowerCase(),
  }));
}

function ProductsPage() {
  const { category } = useParams();
  const location = useLocation();

  const [filters, setFilters] = useState({
    category: "",
    gender: [],
    brands: [],
    colors: [],
    price: 10000,
  });

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const brand = params.get("brand");
    const search = params.get("search")?.toLowerCase() || "";
    setSearchTerm(search);

    const lower = category?.toLowerCase();
    const validCategories = ["bag", "watch", "sneaker"];
    const validGenders = ["man", "woman", "unisex"];

    if (validCategories.includes(lower)) {
      setFilters(prev => ({ ...prev, category: lower }));
    } else if (validGenders.includes(lower)) {
      setFilters(prev => ({ ...prev, gender: [lower] }));
    }

    setFilters(prev => ({
      ...prev,
      brands: brand ? [brand.toLowerCase().replace(/\s/g, '')] : prev.brands,
    }));
  }, [category, location.search]);

  const handleCheckboxChange = (type, value) => {
    if (type === "category") {
      setFilters((prev) => ({ ...prev, category: value }));
    } else {
      setFilters((prev) => {
        const current = prev[type];
        const updated = current.includes(value)
          ? current.filter((v) => v !== value)
          : [...current, value];
        return { ...prev, [type]: updated };
      });
    }
  };

  const handlePriceChange = (value) => {
    setFilters(prev => ({ ...prev, price: value }));
  };

  const resetFilters = () => {
    setFilters({ category: "", gender: [], brands: [], colors: [], price: 10000 });
  };

  const normalizedProducts = normalizeProducts(allProducts);

  const filteredProducts = normalizedProducts.filter((product) => {
    return (
      (!filters.category || product.category === filters.category) &&
      (filters.gender.length === 0 || filters.gender.includes(product.gender)) &&
      (filters.brands.length === 0 || filters.brands.includes(product.brand)) &&
      (filters.colors.length === 0 || filters.colors.includes(product.color)) &&
      product.price <= filters.price &&
      (!searchTerm || product.name.toLowerCase().includes(searchTerm))
    );
  });

  return (
    <div>
      <Header />
      <Navbar />

      {isMobile && (
        <div className="mobile-filter-bar">
          <button onClick={() => setIsFilterOpen(true)}>Filter</button>
        </div>
      )}

      <div className="products-container">
        <FilterSidebar
          filters={filters}
          onCheckboxChange={handleCheckboxChange}
          onPriceChange={handlePriceChange}
          isMobile={isMobile}
          isOpen={isFilterOpen}
          onClose={() => setIsFilterOpen(false)}
        />

        <main className="products-main">
          <div className="filter-actions">
            <h4>{filteredProducts.length} products found</h4>
            <button onClick={resetFilters}>Reset Filters</button>
          </div>
          <section className="products-grid">
            {filteredProducts.map((product) => (
              <Link
                to={`/product-details/${product.id}`}
                key={product.id}
                className="card-link"
                style={{ textDecoration: 'none', color: 'inherit' }}
              >
                <div className="product-card">
                  {product.name}
                  <div className="img-container">
                      <img src={product.image} alt={product.name} />
                  </div>
                </div>
              </Link>
            ))}
            {filteredProducts.length === 0 && <p>No products match your filters.</p>}
          </section>
        </main>
      </div>
      <Footer />
    </div>
  );
}

export default ProductsPage;
  