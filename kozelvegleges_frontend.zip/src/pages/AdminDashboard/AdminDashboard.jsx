import React, { useEffect, useState } from 'react';
import './AdminDashboard.css';
import { useNavigate } from 'react-router-dom';

function AdminDashboard() {
  const [pendingProducts, setPendingProducts] = useState([]);
  const [approvedProducts, setApprovedProducts] = useState([]);
  const [activeTab, setActiveTab] = useState('pending');
  const [selectedImage, setSelectedImage] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    setPendingProducts([
        {
            id: 1,
            name: 'Omega Speedmaster',
            images: [
              '/Images/product_images/orak1_1.jpeg',
              '/Images/product_images/orak1_2.jpeg',
              '/Images/product_images/orak1_3.jpeg',
            ],
            size: '42mm',
            color: 'Silver',
            description: 'Iconic chronograph watch with tachymeter scale.',
            price: '€3200',
            category: 'Watches',
          },
          {
            id: 2,
            name: 'Omega Speedmaster',
            images: [
              '/Images/product_images/orak1_1.jpeg',
              '/Images/product_images/orak1_2.jpeg',
              '/Images/product_images/orak1_3.jpeg',
            ],
            size: '42mm',
            color: 'Silver',
            description: 'Iconic chronograph watch with tachymeter scale.',
            price: '€3200',
            category: 'Watches',
          },

    ]);

    setApprovedProducts([
      {
        id: 3,
        name: 'Chanel Classic Flap Bag',
        images: [
          '/Images/product_images/taska8_1.jpeg',
          '/Images/product_images/taska8_2.jpeg',
          '/Images/product_images/taska8_3.jpeg',
        ],
        size: 'Medium',
        color: 'Black',
        description: 'Timeless quilted leather bag with gold hardware.',
        price: '€5200',
        category: 'Bags',
      },
      {
        id: 4,
        name: 'Chanel Classic Flap Bag',
        images: [
          '/Images/product_images/taska8_1.jpeg',
          '/Images/product_images/taska8_2.jpeg',
          '/Images/product_images/taska8_3.jpeg',
        ],
        size: 'Medium',
        color: 'Black',
        description: 'Timeless quilted leather bag with gold hardware.',
        price: '€5200',
        category: 'Bags',
      },
    ]);
  }, []);

  const approveProduct = (id) => {
    console.log('Approved:', id);
  };

  const unapproveProduct = (id) => {
    console.log('Unapproved:', id);
  };

  const deleteProduct = (id) => {
    console.log('Deleted:', id);
  };

  const handleSignOut = () => {
    localStorage.removeItem("user");
    navigate("/auth");
  };

  const displayedProducts = activeTab === 'pending' ? pendingProducts : approvedProducts;

  return (
    <div className="admin-dashboard">
      <header className="admin-header">
        <div className="admin-header-center">
          <div className="admin-logo">

            <h1>LuxShop Administrator Panel</h1>
          </div>
          <div className="admin-tabs">
            <button
              className={activeTab === 'pending' ? 'active-tab' : ''}
              onClick={() => setActiveTab('pending')}
            >
              Pending Products
            </button>
            <button
              className={activeTab === 'approved' ? 'active-tab' : ''}
              onClick={() => setActiveTab('approved')}
            >
              All Products
            </button>
          </div>
        </div>
        <button className="sign-out-button" onClick={handleSignOut}>Sign Out</button>
      </header>

      <main className="admin-panel">
        <h2>{activeTab === 'pending' ? 'Pending Product Approvals' : 'All Products'}</h2>
        {displayedProducts.map((product) => (
          <div key={product.id} className="product-row">
            <div className="product-image-column">
              <div className="thumbnail-row">
                {product.images.map((img, index) => (
                  <img
                    key={index}
                    src={img}
                    alt={`Thumbnail ${index + 1}`}
                    className={selectedImage[product.id] === img ? 'selected-thumbnail' : ''}
                    onClick={() => setSelectedImage((prev) => ({ ...prev, [product.id]: img }))}
                  />
                ))}
              </div>
              <img
                src={selectedImage[product.id] || product.images[0]}
                alt="Main View"
                className="main-image"
              />
            </div>
            <div className="product-details">
              <h3>{product.name}</h3>
              <p><strong>Category:</strong> {product.category}</p>
              <p><strong>Size:</strong> {product.size}</p>
              <p><strong>Color:</strong> {product.color}</p>
              <p><strong>Description:</strong> {product.description}</p>
              <p><strong>Price:</strong> {product.price}</p>
              <div className="product-actions">
                {activeTab === 'pending' ? (
                  <>
                    <button onClick={() => approveProduct(product.id)} className="hidden"></button>
                    <button onClick={() => approveProduct(product.id)} className="approve-btn">Approve</button>
                    <button onClick={() => unapproveProduct(product.id)} className="unapprove-btn">Unapprove</button>
                  </>
                ) : (
                  <button onClick={() => deleteProduct(product.id)} className="delete-btn">Delete</button>
                )}
              </div>
            </div>
          </div>
        ))}
      </main>
    </div>
  );
}

export default AdminDashboard;
