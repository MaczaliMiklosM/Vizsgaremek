package com.example.demo.product.services;

import com.example.demo.product.model.Product;
import com.example.demo.product.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UpdateProductService {

    private final ProductService productService;

    public Object handle(Product product, Long productId) {
        productService.saveProduct(product);
        return null;
    }
}
