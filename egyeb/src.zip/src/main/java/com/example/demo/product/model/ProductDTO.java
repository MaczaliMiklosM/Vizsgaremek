package com.example.demo.product.model;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProductDTO {
    private Long id;
    private String name;
    private String description;
    private Integer price;
    private String imageUrl;
    private Integer stock;
    private String brand;
    private String color;
    private String size;
    private Product.ProductCondition condition;
    private Product.Gender targetGender;
    private boolean biddingEnabled;
    private Product.BiddingDuration biddingDuration;
    private Product.Status status;
    private Product.Category category;
    private Long uploaderId;
    private String uploadDate;

    public static ProductDTO fromEntity(Product p) {
        return ProductDTO.builder()
                .id(p.getId())
                .name(p.getName())
                .description(p.getDescription())
                .price(p.getPrice())
                .imageUrl(p.getImageUrl())
                .stock(p.getStock())
                .brand(p.getBrand())
                .color(p.getColor())
                .size(p.getSize())
                .condition(p.getCondition())
                .targetGender(p.getTargetGender())
                .biddingEnabled(p.isBiddingEnabled())
                .biddingDuration(p.getBiddingDuration())
                .status(p.getStatus())
                .category(p.getCategory())
                .uploaderId(p.getUploader() != null ? p.getUploader().getUser_id() : null)
                .uploadDate(p.getUploadDate() != null ? p.getUploadDate().toString() : null)
                .build();
    }
}