package com.example.demo.product.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "products")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id")
    private Long id;

    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    private Integer price;

    @Column(name = "image_url")
    private String imageUrl;

    private Integer stock;
    private String brand;
    private String color;
    private String size;

    @Column(name = "product_condition")
    @Enumerated(EnumType.STRING)
    private ProductCondition condition;

    @ManyToOne
    @JoinColumn(name = "uploader_id")
    private User uploader;

    @Column(name = "upload_date")
    private LocalDateTime uploadDate;

    @Enumerated(EnumType.STRING)
    private Category category;

    @Column(name = "target_gender")
    @Enumerated(EnumType.STRING)
    private Gender targetGender;

    @Column(name = "bidding_enabled")
    private boolean biddingEnabled;

    @Column(name = "bidding_duration")
    @Enumerated(EnumType.STRING)
    private BiddingDuration biddingDuration;

    @Enumerated(EnumType.STRING)
    private Status status;

    public enum ProductCondition { NEW, USED }
    public enum Category { SNEAKER, BAG, WATCH }
    public enum Gender { MAN, WOMAN, UNISEX }
    public enum BiddingDuration { _24, _48, _72 }
    public enum Status { APPROVED, UNAPPROVED }
}