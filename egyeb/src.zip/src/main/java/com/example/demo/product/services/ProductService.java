package com.example.demo.product.services;

import com.example.demo.product.ProductRepository;
import com.example.demo.product.model.Product;
import com.example.demo.product.model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    public List<Product> getAllApprovedProducts() {
        return productRepository.findByStatus(Product.Status.APPROVED);
    }

    public List<Product> getProductsByUser(User uploader) {
        return productRepository.findByUploader(uploader);
    }

    public Optional<Product> getById(Long id) {
        return productRepository.findById(id);
    }

    public Product saveProduct(Product product) {
        return productRepository.save(product);
    }

    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }

    public List<Product> getByCategory(Product.Category category) {
        return productRepository.findByCategory(category);
    }

    public List<Product> getAll() {
        return productRepository.findAll();
    }
}