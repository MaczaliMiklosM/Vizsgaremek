package com.example.demo.product;

import com.example.demo.product.model.Product;
import com.example.demo.product.model.User;
import com.example.demo.product.model.Product.Category;
import com.example.demo.product.model.Product.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByUploader(User uploader);
    List<Product> findByCategory(Category category);
    List<Product> findByStatus(Status status);
}