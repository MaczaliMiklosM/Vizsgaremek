
package com.example.demo.auth;

import com.example.demo.product.UserRepository;
import com.example.demo.product.model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
        return new CustomUserDetails(user);
    }


    public void saveUser(String fullName, String email, String encodedPassword,
                         String phoneNumber, String address, String country) {
        User user = User.builder()
                .full_Name(fullName)
                .email(email)
                .password_Hash(encodedPassword)
                .phone_number(phoneNumber)
                .address(address)
                .country(country)
                .role("user")
                .build();
        userRepository.save(user);
    }
}
