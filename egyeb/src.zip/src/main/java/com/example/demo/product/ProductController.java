package com.example.demo.product;

import com.example.demo.product.model.Product;
import com.example.demo.product.model.ProductDTO;
import com.example.demo.product.services.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;

    @GetMapping("/all")
    public ResponseEntity<List<ProductDTO>> getAll() {
        List<ProductDTO> result = productService.getAll()
                .stream().map(ProductDTO::fromEntity).collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/approved")
    public ResponseEntity<List<ProductDTO>> getApproved() {
        List<ProductDTO> result = productService.getAllApprovedProducts()
                .stream().map(ProductDTO::fromEntity).collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProductDTO> getById(@PathVariable Long id) {
        Optional<Product> product = productService.getById(id);
        return product.map(p -> ResponseEntity.ok(ProductDTO.fromEntity(p)))
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/upload")
    public ResponseEntity<ProductDTO> upload(@RequestBody Product product) {
        Product saved = productService.saveProduct(product);
        return ResponseEntity.ok(ProductDTO.fromEntity(saved));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        productService.deleteProduct(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/category/{category}")
    public ResponseEntity<List<ProductDTO>> getByCategory(@PathVariable Product.Category category) {
        List<ProductDTO> result = productService.getByCategory(category)
                .stream().map(ProductDTO::fromEntity).collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }
}