package com.example.demo.enums;

public enum PaymentMethod {
    CARD
}

