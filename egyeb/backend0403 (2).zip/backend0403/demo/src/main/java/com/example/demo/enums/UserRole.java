package com.example.demo.enums;

public enum UserRole {
    USER,
    ADMIN
}

