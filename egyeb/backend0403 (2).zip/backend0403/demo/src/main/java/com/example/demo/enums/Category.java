package com.example.demo.enums;

public enum Category {
    SNEAKER,
    BAG,
    WATCH
}

