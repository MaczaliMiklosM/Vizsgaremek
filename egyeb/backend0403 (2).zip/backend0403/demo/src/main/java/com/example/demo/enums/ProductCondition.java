package com.example.demo.enums;

public enum ProductCondition {
    NEW,
    USED
}

