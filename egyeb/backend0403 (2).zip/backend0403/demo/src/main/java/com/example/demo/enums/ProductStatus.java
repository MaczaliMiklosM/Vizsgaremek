package com.example.demo.enums;

public enum ProductStatus {
    PENDING,
    APPROVED,
    REJECTED
}
