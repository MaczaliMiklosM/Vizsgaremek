package com.example.demo.enums;

public enum Status {
    APPROVED,
    UNAPPROVED,
    SOLD
}

