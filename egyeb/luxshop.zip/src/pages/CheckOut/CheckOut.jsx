import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/Header/Header';
import Navbar from '../../components/Navbar/Navbar';
import Footer from '../../components/Footer/Footer';
import './CheckOut.css';

const steps = ['Shipping', 'Payment', 'Summary'];

const Checkout = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    city: '',
    zip: '',
    paymentMethod: '',
    cardNumber: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleNext = () => {
    if (step < steps.length - 1) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 0) setStep(step - 1);
  };

  const handlePayment = () => {
    alert('Payment Successful! Redirecting to home page...');
    navigate('/');
  };

  const renderStep = () => {
    switch (step) {
      case 0:
        return (
          <div className="checkout-step">
            <h2>Shipping Information</h2>
            <input type="text" name="name" placeholder="Full Name" onChange={handleChange} required />
            <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
            <input type="text" name="address" placeholder="Address" onChange={handleChange} required />
            <input type="text" name="city" placeholder="City" onChange={handleChange} required />
            <input type="text" name="zip" placeholder="ZIP Code" onChange={handleChange} required />
            <button onClick={handleNext}>Next</button>
          </div>
        );
      case 1:
        return (
          <div className="checkout-step">
            <h2>Payment Method</h2>
            <select name="paymentMethod" onChange={handleChange} required>
              <option value="">Select Payment Method</option>
              <option value="credit">Credit Card</option>
              <option value="paypal">PayPal</option>
            </select>
            {formData.paymentMethod === 'credit' && (
              <input type="text" name="cardNumber" placeholder="Card Number" onChange={handleChange} required />
            )}
            <div className="button-group">
              <button onClick={handleBack}>Back</button>
              <button onClick={handleNext}>Next</button>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="checkout-summary">
            <h2>Order Summary</h2>
            <p><strong>Name:</strong> {formData.name}</p>
            <p><strong>Email:</strong> {formData.email}</p>
            <p><strong>Address:</strong> {formData.address}, {formData.city}, {formData.zip}</p>
            <p><strong>Payment:</strong> {formData.paymentMethod}</p>
            <div className="button-group">
              <button onClick={handleBack}>Back</button>
              <button onClick={handlePayment}>Pay Now</button>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="container">
      <Header />
      <Navbar />
      <div className="checkout-container">
        <h1>Checkout</h1>

        <div className="checkout-steps">
          {steps.map((label, index) => (
            <div key={index} className="checkout-step-indicator">
              <div className={`checkout-step-circle ${index <= step ? 'active' : ''}`}>{index + 1}</div>
              <div className={`checkout-step-label ${index <= step ? 'active' : ''}`}>{label}</div>
              {index < steps.length - 1 && (
                <div className={`checkout-step-line ${index < step ? 'active' : ''}`} />
              )}
            </div>
          ))}
        </div>

        {renderStep()}
      </div>
      <Footer />
    </div>
  );
};

export default Checkout;