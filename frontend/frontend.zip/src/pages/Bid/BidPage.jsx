import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Header from "../../components/Header/Header";
import Navbar from "../../components/Navbar/Navbar";
import Footer from "../../components/Footer/Footer";
import RequireAuth from '../../components/Auth/RequireAuth';
import axios from 'axios';
import "./BidPage.css";

function BidPage() {
  const { id } = useParams();  // Termék ID a URL-ből
  const [product, setProduct] = useState(null);
  const [bids, setBids] = useState([]);  // Tároljuk a liciteket
  const [bidInput, setBidInput] = useState("");  // A felhasználó által megadott licit
  const [message, setMessage] = useState("");  // Visszajelző üzenet

  useEffect(() => {
    const fetchProductData = async () => {
      try {
        console.log("Fetching product data for ID:", id);  // Debug log
        const token = localStorage.getItem("token");  // Token lekérése a localStorage-ból
        if (!token) {
          console.log("No token found");
          setMessage("Please log in first.");
          return;
        }
  
        const response = await axios.get(`/api/products/getProductById/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`  // JWT token hozzáadása a kéréshez
          }
        });
        console.log("Product data:", response.data);  // Debug log
        setProduct(response.data);
  
        const bidResponse = await axios.get(`/api/bids/product/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`  // JWT token hozzáadása a kéréshez
          }
        });
        console.log("Bid data:", bidResponse.data);  // Debug log
        setBids(bidResponse.data);
  
      } catch (error) {
        console.error("Error fetching product:", error);
        setMessage("Failed to fetch product details.");
      }
    };
  
    fetchProductData();
  }, [id]);
  
  
  


  // A legmagasabb licit kiszámítása
  const highestBid = bids.length > 0 
    ? Math.max(...bids.map((b) => b.amount)) 
    : product?.startingPrice || 0;
  
  console.log("Highest bid: ", highestBid);  // Debug log

  // A licit elküldése
  const handleBidSubmit = async () => {
    const newBid = parseFloat(bidInput);
  
    // Ellenőrizzük, hogy a licit valóban nagyobb-e, mint a legmagasabb
    if (isNaN(newBid) || newBid <= highestBid) {
      setMessage(`Bid must be higher than $${highestBid}`);
      return;
    }
  
    try {
      const token = localStorage.getItem("token");
if (!token) {
  setMessage("Please log in first.");
  return;
}

const response = await axios.get(`/api/bids/product/${id}`, {
  headers: {
    Authorization: `Bearer ${token}` // JWT token hozzáadása
  }
});

  
      setBids([response.data, ...bids]);
      setMessage(`Your bid of $${newBid} has been placed!`);
      setBidInput("");  // Kiürítjük a licit mezőt
  
    } catch (error) {
      console.error("Error placing bid:", error);
      setMessage("Failed to place bid.");
    }
  };
  

  // Ha a termék nem található, megjelenítünk egy hibaüzenetet
  if (!product) {
    return <div style={{ padding: "50px", textAlign: "center" }}>Product not found.</div>;
  }

  // A dátum formázása
  const formatDate = (dateString) => {
    const date = new Date(dateString); // Az ISO formátumból JavaScript Date objektum
    return date.toLocaleString(); // Formázott dátum
  };

  return (
    <RequireAuth>
      <div>
        <Header />
        <Navbar />

        <div className="bid-container">
          <div className="bid-card">
            <h2>{product.name}</h2>
            <img src={product.image} alt={product.name} className="bid-image" />
            <p><strong>Starting Price:</strong> ${product.startingPrice}</p>
            <p><strong>Highest Bid:</strong> ${highestBid}</p>

            <input
              type="number"
              placeholder={`Enter more than $${highestBid}`}
              value={bidInput}
              onChange={(e) => setBidInput(e.target.value)}
              className="bid-input"
            />
            <button className="bid-button" onClick={handleBidSubmit}>Place Bid</button>
            {message && <p className="bid-message">{message}</p>}

            <div className="bid-history">
              <h4>Bid History</h4>
              {bids.length === 0 ? (
                <p>No bids yet.</p>
              ) : (
                <ul>
                  {bids.map((b, i) => (
                    <li key={i}>
                      💰 ${b.amount} <span className="time">({formatDate(b.time)})</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        <Footer />
      </div>
    </RequireAuth>
  );
}

export default BidPage;
