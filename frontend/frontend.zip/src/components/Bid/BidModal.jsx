// src/components/BidModal/BidModal.jsx
import React from 'react';
import './BidModal.css';

const BidModal = ({ open, onClose, handleBidSubmit, bidInput, setBidInput, highestBid, message }) => {
  if (!open) return null;

  return (
    <div className="modal">
      <div className="modal-content">
        <h2>Place Your Bid</h2>
        <input
          type="number"
          placeholder={`Enter more than $${highestBid}`}
          value={bidInput}
          onChange={(e) => setBidInput(e.target.value)}
          className="bid-input"
        />
        <button className="bid-button" onClick={handleBidSubmit}>Place Bid</button>
        {message && <p className="bid-message">{message}</p>}
        <button className="close-button" onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default BidModal;
