create table user (
    id              int             not null       primary key      auto_increment,
    username        varchar(30)     not null,
    password        varchar(100)     not null,
    first_name      varchar(30)     not null,
    last_name       varchar(30)     not null,
    email           varchar(100)    not null,
    phone           varchar(30)     not null,
    role            varchar(30)     not null
);