insert into permission (id) values
    ('GET_SUBMARINE'),
    ('SINK_SUBMARINE'),
    ('SHOOT_TORPEDO');

