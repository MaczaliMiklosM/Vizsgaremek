insert into allocate (user_id, permission_id) values
    (1, 'GET_SUBMARINE'),
    (2, 'GET_SUBMARINE'),
    (1, 'SINK_SUBMARINE'),
    (2, 'SINK_SUBMARINE'),
    (2, 'SHOOT_TORPEDO');
