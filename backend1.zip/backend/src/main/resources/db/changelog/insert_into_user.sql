insert into user (id, username, password, first_name, last_name, email, phone, role) values
   (1, 'yxcv', '$2a$10$If/D4GuJx3fq1Ovm3XR67uIIj/KDz5LUCYx23uAmViYj1NRYW.AY6', 'János', 'Általános', 'jani@nyirszikszi.hu', '20/555-1224', 'COMMON_USER'),
   (2, 'admin', '$2a$10$GGJ.8Jx3EMwcXTMy7ilFyuckfa037QtDNP6uf57aH2ZN.yhg3NLbG', 'Károly', 'Komoly', 'karoly@harvard.us', '90/555-0000', 'ADMINISTRATOR');
