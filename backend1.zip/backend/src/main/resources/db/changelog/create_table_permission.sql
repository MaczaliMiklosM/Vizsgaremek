create table permission(
    id  varchar(30) not null primary key
);