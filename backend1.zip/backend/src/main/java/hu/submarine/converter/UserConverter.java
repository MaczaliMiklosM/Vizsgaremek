package hu.submarine.converter;

import hu.submarine.dto.ReadUser;
import hu.submarine.model.User;

public class UserConverter {
    public static ReadUser convertModelToRead(User user) {
        ReadUser readUser = new ReadUser();
        readUser.setId( user.getId() );
        readUser.setFirstName( user.getFirstName() );
        readUser.setLastName( user.getLastName() );
        readUser.setRole( user.getRole() );
        return readUser;
    }
}
