package hu.submarine.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class ReadSubmarine {
    private Integer id;
    private String name;
    private int maxDepth;

    public ReadSubmarine(Integer id, String name, int maxDepth) {
        this.id = id;
        this.name = name;
        this.maxDepth = maxDepth;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMaxDepth() {
        return maxDepth;
    }

    public void setMaxDepth(int maxDepth) {
        this.maxDepth = maxDepth;
    }
}
