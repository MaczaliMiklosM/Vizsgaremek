package hu.submarine.model;

public enum Permission {
        GET_SUBMARINE,
        SINK_SUBMARINE,
        SHOOT_TORPEDO
}
