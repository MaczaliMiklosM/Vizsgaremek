package hu.submarine.controller;

import hu.submarine.dto.ReadSubmarine;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@Tag(name="Managing submarines")
@RequestMapping("/submarine")
public class SubmarineController {

    @PreAuthorize("hasAuthority('GET_SUBMARINE')")
    @GetMapping("/{id}")
    @Operation(summary = "Read metadata of selected submarine")
    public ReadSubmarine readSubmarine( @PathVariable int id ) {
        return new ReadSubmarine(id, "Nautilus", 600);
    }

    @PreAuthorize("hasAuthority('SINK_SUBMARINE')")
    @PostMapping("/sink")
    @Operation(summary = "sink submarine")
    public String sinkSubmarine() {
        return "Submarine reached 100 m depth";
    }

    @PreAuthorize("hasAuthority('SHOOT_TORPEDO')")
    @PutMapping("/shoot")
    @Operation(summary = "shoot a torpedo")
    public String shoot(){
        return "The enemy is destroyed";
    }
}
