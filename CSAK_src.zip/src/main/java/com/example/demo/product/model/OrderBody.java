package com.example.demo.product.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "order_body")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderBody {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "order_id")
    private OrderHeader order;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    private int quantity;

    @Column(name = "unit_price")
    private int unitPrice;
}