package com.example.demo.product.services;

import com.example.demo.product.model.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class CartService {

    private final Map<Long, Map<Long, Integer>> userCarts = new HashMap<>();

    public void addToCart(Long userId, Product product, int quantity) {
        userCarts.putIfAbsent(userId, new HashMap<>());
        Map<Long, Integer> cart = userCarts.get(userId);
        cart.put(product.getId(), cart.getOrDefault(product.getId(), 0) + quantity);
    }

    public Map<Long, Integer> getCart(Long userId) {
        return userCarts.getOrDefault(userId, new HashMap<>());
    }

    public void clearCart(Long userId) {
        userCarts.remove(userId);
    }
}