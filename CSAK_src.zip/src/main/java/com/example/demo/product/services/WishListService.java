package com.example.demo.product.services;

import com.example.demo.product.model.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@RequiredArgsConstructor
public class WishListService {

    private final Map<Long, Set<Long>> userWishlists = new HashMap<>();

    public void addToWishlist(Long userId, Product product) {
        userWishlists.putIfAbsent(userId, new HashSet<>());
        userWishlists.get(userId).add(product.getId());
    }

    public void removeFromWishlist(Long userId, Product product) {
        if (userWishlists.containsKey(userId)) {
            userWishlists.get(userId).remove(product.getId());
        }
    }

    public Set<Long> getWishlist(Long userId) {
        return userWishlists.getOrDefault(userId, Collections.emptySet());
    }

    public boolean isInWishlist(Long userId, Product product) {
        return userWishlists.getOrDefault(userId, Collections.emptySet()).contains(product.getId());
    }

    public void clearWishlist(Long userId) {
        userWishlists.remove(userId);
    }
}
