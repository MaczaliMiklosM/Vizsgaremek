package com.example.demo.product;

import com.example.demo.product.model.Product;
import com.example.demo.product.services.WishListService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/api/wishlist")
@RequiredArgsConstructor
public class WishListController {

    private final WishListService wishlistService;
    private final ProductRepository productRepository;

    @PostMapping("/add")
    public ResponseEntity<Void> addToWishlist(@RequestParam Long userId, @RequestParam Long productId) {
        Product product = productRepository.findById(productId).orElse(null);
        if (product == null) return ResponseEntity.notFound().build();
        wishlistService.addToWishlist(userId, product);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{userId}")
    public ResponseEntity<Set<Long>> getWishlist(@PathVariable Long userId) {
        return ResponseEntity.ok(wishlistService.getWishlist(userId));
    }

    @DeleteMapping("/remove")
    public ResponseEntity<Void> removeFromWishlist(@RequestParam Long userId, @RequestParam Long productId) {
        Product product = productRepository.findById(productId).orElse(null);
        if (product == null) return ResponseEntity.notFound().build();
        wishlistService.removeFromWishlist(userId, product);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/clear/{userId}")
    public ResponseEntity<Void> clearWishlist(@PathVariable Long userId) {
        wishlistService.clearWishlist(userId);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/contains")
    public ResponseEntity<Boolean> isInWishlist(@RequestParam Long userId, @RequestParam Long productId) {
        Product product = productRepository.findById(productId).orElse(null);
        if (product == null) return ResponseEntity.ok(false);
        return ResponseEntity.ok(wishlistService.isInWishlist(userId, product));
    }
}
