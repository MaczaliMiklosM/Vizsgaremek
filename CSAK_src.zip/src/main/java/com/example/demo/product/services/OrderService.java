package com.example.demo.product.services;

import com.example.demo.product.OrderRepository;
import com.example.demo.product.model.OrderBody;
import com.example.demo.product.model.OrderHeader;
import com.example.demo.product.model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;

    public List<OrderHeader> getOrdersByUser(User user) {
        return orderRepository.findByUser(user);
    }

    public OrderHeader placeOrder(User user, List<OrderBody> items, String address, OrderHeader.PaymentMethod paymentMethod) {
        int total = items.stream().mapToInt(i -> i.getUnitPrice() * i.getQuantity()).sum();
        OrderHeader order = OrderHeader.builder()
                .user(user)
                .items(items)
                .totalAmount(total)
                .status("placed")
                .shippingAddress(address)
                .paymentMethod(paymentMethod)
                .build();

        items.forEach(i -> i.setOrder(order));
        return orderRepository.save(order);
    }

    public List<OrderHeader> getAllOrders() {
        return orderRepository.findAll();
    }

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

    public OrderHeader getById(Long id) {
        return orderRepository.findById(id).orElse(null);
    }
}