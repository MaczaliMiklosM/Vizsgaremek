package com.example.demo.product;

import com.example.demo.product.model.Bid;
import com.example.demo.product.model.Product;
import com.example.demo.product.model.User;
import com.example.demo.product.services.BidService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bids")
@RequiredArgsConstructor
public class BidController {

    private final BidService bidService;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    @PostMapping("/place")
    public ResponseEntity<Bid> placeBid(@RequestParam Long userId,
                                        @RequestParam Long productId,
                                        @RequestParam int amount) {
        User user = userRepository.findById(userId).orElse(null);
        Product product = productRepository.findById(productId).orElse(null);
        if (user == null || product == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(bidService.placeBid(user, product, amount));
    }

    @GetMapping("/product/{productId}")
    public ResponseEntity<List<Bid>> getByProduct(@PathVariable Long productId) {
        Product product = productRepository.findById(productId).orElse(null);
        if (product == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(bidService.getBidsByProduct(product));
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Bid>> getByUser(@PathVariable Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(bidService.getBidsByUser(user));
    }

    @GetMapping("/highest/{productId}")
    public ResponseEntity<Bid> getHighestBid(@PathVariable Long productId) {
        Product product = productRepository.findById(productId).orElse(null);
        if (product == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(bidService.getHighestBid(product));
    }
}