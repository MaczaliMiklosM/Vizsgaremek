package com.example.demo.product;

import com.example.demo.product.model.OrderBody;
import com.example.demo.product.model.OrderHeader;
import com.example.demo.product.model.User;
import com.example.demo.product.services.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;
    private final UserRepository userRepository;

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<OrderHeader>> getByUser(@PathVariable Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(orderService.getOrdersByUser(user));
    }

    @GetMapping("/all")
    public ResponseEntity<List<OrderHeader>> getAll() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    @PostMapping("/place")
    public ResponseEntity<OrderHeader> placeOrder(@RequestParam Long userId,
                                                  @RequestBody List<OrderBody> items,
                                                  @RequestParam String address,
                                                  @RequestParam OrderHeader.PaymentMethod paymentMethod) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(orderService.placeOrder(user, items, address, paymentMethod));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        orderService.deleteOrder(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrderHeader> getById(@PathVariable Long id) {
        OrderHeader order = orderService.getById(id);
        return order != null ? ResponseEntity.ok(order) : ResponseEntity.notFound().build();
    }
}