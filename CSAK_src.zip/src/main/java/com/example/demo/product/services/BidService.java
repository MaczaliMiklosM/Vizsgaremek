package com.example.demo.product.services;

import com.example.demo.product.BidRepository;
import com.example.demo.product.model.Bid;
import com.example.demo.product.model.Product;
import com.example.demo.product.model.User;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BidService {

    private final BidRepository bidRepository;

    public Bid placeBid(User user, Product product, int amount) {
        Bid bid = Bid.builder().user(user).product(product).amount(amount).build();
        return bidRepository.save(bid);
    }

    public List<Bid> getBidsByProduct(Product product) {
        return bidRepository.findByProduct(product);
    }

    public List<Bid> getBidsByUser(User user) {
        return bidRepository.findByUser(user);
    }

    public Bid getHighestBid(Product product) {
        return bidRepository.findTopByProductOrderByAmountDesc(product);
    }
}